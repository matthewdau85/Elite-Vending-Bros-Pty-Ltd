
import React, { useState, useEffect, useMemo, useCallback } from "react";
import { Link, useNavigate } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Alert, Machine, Sale, MachineStock, Location, Product, Payout, ServiceTicket } from "@/api/entities";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  AlertTriangle, 
  Coffee, 
  DollarSign, 
  TrendingUp, 
  MapPin,
  Calendar,
  Bell,
  Zap,
  Printer,
  CloudSun,
  Clock,
  PlayCircle // New import for the PlayCircle icon
} from "lucide-react";
import { format, isWithinInterval, isPast, differenceInHours } from "date-fns";
import { motion } from "framer-motion";
import { toast } from "sonner";
import { syncNayaxData } from "@/api/functions";

import StatsOverview from "../components/dashboard/StatsOverview";
import AlertsPanel from "../components/dashboard/AlertsPanel";
import WeatherWidget from "../components/dashboard/WeatherWidget";
import LiveMapWidget from "../components/dashboard/LiveMapWidget";
import WeatherSalesAnalytics from "../components/dashboard/WeatherSalesAnalytics";
import TopLocationsTable from "../components/dashboard/TopLocationsTable";
import { PeriodProvider, usePeriod } from "../components/analytics/PeriodToolbar";
import PeriodToolbar from "../components/analytics/PeriodToolbar";
import { EnhancedAreaChart, EnhancedBarChart } from "../components/analytics/EnhancedChart";
import { PageSkeleton } from '../components/shared/Skeletons';
import ContextHelp from '../components/help/ContextHelp';
import QuickTour from '../components/help/QuickTour'; // New import
import { useHelpTour } from '../components/help/useHelpTour'; // New import
import { tours } from '../components/help/content/tours'; // New import

// SLA Breaches Component
const SLABreachesPanel = ({ tickets, isLoading }) => {
  const overdueTickets = useMemo(() => {
    if (!tickets.length) return [];
    
    return tickets
      .filter(ticket => {
        if (ticket.status === 'completed' || ticket.status === 'cancelled') return false;
        if (!ticket.resolution_sla) return false;
        
        // Check if overdue (accounting for snooze)
        const dueDate = ticket.snoozed_until ? new Date(ticket.snoozed_until) : new Date(ticket.resolution_sla);
        return isPast(dueDate);
      })
      .sort((a, b) => {
        const aDue = a.snoozed_until ? new Date(a.snoozed_until) : new Date(a.resolution_sla);
        const bDue = b.snoozed_until ? new Date(b.snoozed_until) : new Date(b.resolution_sla);
        return aDue - bDue; // Most overdue first
      })
      .slice(0, 5); // Top 5 most critical
  }, [tickets]);

  const formatOverdue = (ticket) => {
    const dueDate = ticket.snoozed_until ? new Date(ticket.snoozed_until) : new Date(ticket.resolution_sla);
    const hoursOverdue = differenceInHours(new Date(), dueDate);
    
    if (hoursOverdue < 24) {
      return `${hoursOverdue}h overdue`;
    }
    return `${Math.floor(hoursOverdue / 24)}d overdue`;
  };

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'urgent': return 'bg-red-100 text-red-800 border-red-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      default: return 'bg-blue-100 text-blue-800 border-blue-200';
    }
  };

  return (
    <Card className="border-0 shadow-lg">
      <CardHeader className="border-b bg-white">
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2 text-slate-900">
            <Clock className="w-5 h-5 text-red-500" />
            SLA Breaches ({overdueTickets.length})
          </CardTitle>
          {overdueTickets.length > 0 && (
            <Badge variant="destructive" className="bg-red-100 text-red-800">
              Action Required
            </Badge>
          )}
        </div>
      </CardHeader>
      <CardContent className="p-0">
        {isLoading ? (
          <div className="p-6 space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className="w-10 h-10 bg-slate-200 rounded animate-pulse" />
                <div className="flex-1">
                  <div className="h-4 bg-slate-200 rounded w-32 mb-1 animate-pulse" />
                  <div className="h-3 bg-slate-200 rounded w-48 animate-pulse" />
                </div>
                <div className="h-6 w-16 bg-slate-200 rounded animate-pulse" />
              </div>
            ))}
          </div>
        ) : overdueTickets.length === 0 ? (
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mx-auto mb-4">
              <Clock className="w-8 h-8 text-green-500" />
            </div>
            <h3 className="font-semibold text-slate-900 mb-2">All SLAs On Track</h3>
            <p className="text-slate-500 text-sm">No service tickets are overdue</p>
          </div>
        ) : (
          <div className="divide-y divide-slate-100">
            {overdueTickets.map((ticket, index) => (
              <motion.div
                key={ticket.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: index * 0.05 }}
                className="p-4 hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <div className="flex items-start gap-4">
                  <div className="p-2 rounded-lg bg-red-100">
                    <Clock className="w-5 h-5 text-red-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-2">
                      <h4 className="font-medium text-slate-900 text-sm truncate">
                        {ticket.title}
                      </h4>
                      <Badge className={getPriorityColor(ticket.priority)}>
                        {ticket.priority}
                      </Badge>
                    </div>
                    <p className="text-sm text-slate-600 mt-1 line-clamp-2">
                      {ticket.description}
                    </p>
                    <div className="flex items-center gap-4 mt-2 text-xs">
                      <span className="text-slate-500">Ticket #{ticket.id.slice(0, 8)}</span>
                      <span className="font-medium text-red-600">{formatOverdue(ticket)}</span>
                      {ticket.assigned_to && (
                        <span className="text-slate-500">Assigned to {ticket.assigned_to}</span>
                      )}
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
        
        {overdueTickets.length > 0 && (
          <div className="p-4 border-t bg-slate-50">
            <Link to="/servicetickets">
              <Button variant="outline" className="w-full" size="sm">
                View All Service Tickets
              </Button>
            </Link>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

// Refund Rate Chart Component
const RefundRateChart = ({ sales, isLoading }) => {
  const { dateRange } = usePeriod();
  
  const chartData = useMemo(() => {
    if (!sales.length) return [];
    
    const filteredSales = sales.filter(sale => {
      const saleDate = new Date(sale.sale_datetime);
      return isWithinInterval(saleDate, dateRange);
    });

    // Group by day and calculate refund rates
    const dailyStats = {};
    
    filteredSales.forEach(sale => {
      const day = format(new Date(sale.sale_datetime), 'yyyy-MM-dd');
      if (!dailyStats[day]) {
        dailyStats[day] = {
          date: format(new Date(sale.sale_datetime), 'MMM dd'),
          totalSales: 0,
          refunds: 0,
          refundRate: 0
        };
      }
      
      dailyStats[day].totalSales += 1;
      if (sale.status === 'refunded') {
        dailyStats[day].refunds += 1;
      }
    });

    return Object.values(dailyStats).map(day => ({
      ...day,
      refundRate: day.totalSales > 0 ? (day.refunds / day.totalSales) * 100 : 0
    })).sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [sales, dateRange]);

  const formatPercentage = (value) => `${value.toFixed(1)}%`;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Refund Rate</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <EnhancedBarChart
            data={chartData}
            dataKeys={['refundRate']}
            xAxisKey="date"
            height={250}
            formatValue={formatPercentage}
            colors={['#ef4444']}
            showLegend={false}
          />
        )}
      </CardContent>
    </Card>
  );
};

// Revenue Chart Component
const RevenueChart = ({ sales, isLoading }) => {
  const { dateRange } = usePeriod();
  
  const chartData = useMemo(() => {
    if (!sales.length) return [];
    
    const filteredSales = sales.filter(sale => {
      const saleDate = new Date(sale.sale_datetime);
      return isWithinInterval(saleDate, dateRange);
    });

    // Group by day
    const dailyRevenue = {};
    
    filteredSales.forEach(sale => {
      const day = format(new Date(sale.sale_datetime), 'yyyy-MM-dd');
      if (!dailyRevenue[day]) {
        dailyRevenue[day] = {
          date: format(new Date(sale.sale_datetime), 'MMM dd'),
          revenue: 0,
          transactions: 0
        };
      }
      
      dailyRevenue[day].revenue += (sale.total_amount || 0) / 100; // Convert to dollars
      dailyRevenue[day].transactions += 1;
    });

    return Object.values(dailyRevenue).sort((a, b) => new Date(a.date) - new Date(b.date));
  }, [sales, dateRange]);

  const formatCurrency = (value) => `$${value.toLocaleString()}`;

  return (
    <Card>
      <CardHeader>
        <CardTitle>Daily Revenue</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="h-64 flex items-center justify-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
          </div>
        ) : (
          <EnhancedAreaChart
            data={chartData}
            dataKeys={['revenue']}
            xAxisKey="date"
            height={250}
            formatValue={formatCurrency}
            colors={['#3b82f6']}
            showLegend={false}
          />
        )}
      </CardContent>
    </Card>
  );
};

// Main Dashboard Content Component
const DashboardContent = () => {
  const [alerts, setAlerts] = useState([]);
  const [machines, setMachines] = useState([]);
  const [sales, setSales] = useState([]);
  const [products, setProducts] = useState([]);
  const [locations, setLocations] = useState([]);
  const [payouts, setPayouts] = useState([]);
  const [tickets, setTickets] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [isTourActive, setIsTourActive] = useState(false); // New state for tour
  const { isCompleted: isTourCompleted, markAsCompleted } = useHelpTour('dashboard-overview'); // New hook for tour completion
  const navigate = useNavigate();

  const handleStartTour = () => {
    setIsTourActive(true);
  };
  
  const handleCloseTour = () => {
    setIsTourActive(false);
    markAsCompleted();
  };

  const loadDashboardData = useCallback(async () => {
    setLoading(true);
    try {
      const [
        alertsData, 
        machinesData, 
        salesData, 
        productsData, 
        locationsData, 
        payoutsData, 
        ticketsData
      ] = await Promise.all([
        Alert.filter({ status: "open" }, "-alert_datetime", 50),
        Machine.list("-updated_date", 100),
        Sale.list("-sale_datetime", 500),
        Product.list(),
        Location.list(),
        Payout.list(),
        ServiceTicket.list("-created_date", 100)
      ]);

      setAlerts(alertsData || []);
      setMachines(machinesData || []);
      setSales(salesData || []);
      setProducts(productsData || []);
      setLocations(locationsData || []);
      setPayouts(payoutsData || []);
      setTickets(ticketsData || []);

    } catch (error) {
      console.error("Error loading dashboard data:", error);
      toast.error("Failed to load dashboard data. Please try again.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    loadDashboardData();
  }, [loadDashboardData]);

  useEffect(() => {
    // Automatically prompt for tour on first visit if not completed
    if (!loading && !isTourCompleted && !isTourActive) {
      // Use a timeout to not be too intrusive
      const timer = setTimeout(() => {
         toast("Welcome! Want a quick tour of the dashboard?", {
            action: {
              label: "Start Tour",
              onClick: () => handleStartTour(),
            },
            duration: 10000,
         });
      }, 2000);
      return () => clearTimeout(timer);
    }
  }, [loading, isTourCompleted, isTourActive]);

  const handleSync = async () => {
    setIsSyncing(true);
    toast.info("Starting data synchronization...");
    
    try {
      const response = await syncNayaxData({});
      
      if (response?.data?.success) {
        toast.success("Data synchronization completed successfully!");
        await loadDashboardData();
      } else {
        throw new Error(response?.data?.error || "Sync failed");
      }
    } catch (error) {
      console.error("Sync error:", error);
      toast.error(`Sync failed: ${error.message}`);
      toast.info("You can manage sync settings in the Admin panel.");
    } finally {
      setIsSyncing(false);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  const handleExportCsv = async (dateRange) => {
    const filteredSales = sales.filter(sale => {
      const saleDate = new Date(sale.sale_datetime);
      return isWithinInterval(saleDate, dateRange);
    });

    const csvData = filteredSales.map(sale => ({
      date: format(new Date(sale.sale_datetime), 'yyyy-MM-dd HH:mm:ss'),
      transaction_id: sale.transaction_id,
      machine_id: sale.machine_id,
      product_sku: sale.product_sku,
      quantity: sale.quantity,
      unit_price: sale.unit_price,
      total_amount: sale.total_amount,
      payment_method: sale.payment_method,
      status: sale.status
    }));

    const headers = Object.keys(csvData[0] || {});
    const csvContent = [
      headers.join(','),
      ...csvData.map(row => headers.map(header => row[header]).join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `dashboard-export-${format(new Date(), 'yyyy-MM-dd')}.csv`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    a.remove();

    toast.success("Dashboard data exported successfully!");
  };

  if (loading) {
    return <PageSkeleton />;
  }

  return (
    <div className="p-4 md:p-8 bg-slate-50 min-h-screen">
      <div className="max-w-7xl mx-auto space-y-8">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4 no-print">
          <div className="flex items-center gap-3">
            <div>
              <h1 className="text-3xl font-bold text-slate-900">Operations Dashboard</h1>
              <p className="text-slate-600 mt-1">
                {format(new Date(), "EEEE, MMMM d, yyyy")} • Real-time overview
              </p>
            </div>
            <ContextHelp articleSlug="dashboard-overview" />
          </div>
          <div className="flex gap-3">
            {!isTourCompleted && (
               <Button variant="outline" size="sm" onClick={handleStartTour}>
                 <PlayCircle className="w-4 h-4 mr-2" />
                 Take a Tour
               </Button>
            )}
            <Button variant="outline" size="sm" onClick={handlePrint}>
              <Printer className="w-4 h-4 mr-2" />
              Generate PDF
            </Button>
            <Button 
              size="sm" 
              className="bg-blue-600 hover:bg-blue-700" 
              onClick={handleSync}
              disabled={isSyncing}
            >
              <Zap className={`w-4 h-4 mr-2 ${isSyncing ? 'animate-spin' : ''}`} />
              {isSyncing ? 'Syncing...' : 'Sync Now'}
            </Button>
          </div>
        </div>

        {/* Period Toolbar */}
        <PeriodToolbar 
          onExportCsv={handleExportCsv}
          exportLabel="Export Dashboard Data"
        />

        {/* Stats Overview */}
        <div id="stats-overview-wrapper"> {/* Added ID for tour */}
          <StatsOverview 
            machines={machines} 
            sales={sales} 
            alerts={alerts} 
            payouts={payouts}
            isLoading={loading}
          />
        </div>

        {/* Charts Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8" id="charts-grid-wrapper"> {/* Added ID for tour */}
          <RevenueChart sales={sales} isLoading={loading} />
          <RefundRateChart sales={sales} isLoading={loading} />
        </div>

        {/* Secondary Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-8" id="secondary-grid-wrapper"> {/* Added ID for tour */}
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
            <TopLocationsTable 
              sales={sales}
              locations={locations}
              machines={machines}
              isLoading={loading}
            />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
            <AlertsPanel 
              alerts={alerts}
              isLoading={loading}
              onRefresh={loadDashboardData}
            />
          </motion.div>
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3 }}>
            <SLABreachesPanel 
              tickets={tickets}
              isLoading={loading}
            />
          </motion.div>
        </div>

        {/* Live Operations Map */}
        <div id="live-map-wrapper"> {/* Added ID for tour */}
          <LiveMapWidget 
            machines={machines}
            locations={locations}
            isLoading={loading}
          />
        </div>

        {/* Weather Widget */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <WeatherWidget />
        </div>

        {/* Weather-Sales Analytics */}
        <WeatherSalesAnalytics 
          locations={locations}
          isLoading={loading}
        />

        {/* Quick Actions */}
        <div id="quick-actions-wrapper"> {/* Added ID for tour */}
          <Card className="mt-8 border-0 shadow-md no-print">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="w-5 h-5 text-blue-600" />
                Quick Actions
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Link to={createPageUrl("Alerts")}>
                  <Button variant="outline" className="h-20 w-full flex flex-col gap-2 hover:shadow-md transition-all">
                    <AlertTriangle className="w-6 h-6" />
                    <span className="text-sm">View All Alerts</span>
                  </Button>
                </Link>
                <Link to={createPageUrl("Machines")}>
                  <Button variant="outline" className="h-20 w-full flex flex-col gap-2 hover:shadow-md transition-all">
                    <Coffee className="w-6 h-6" />
                    <span className="text-sm">Manage Machines</span>
                  </Button>
                </Link>
                <Link to={createPageUrl("Routes")}>
                  <Button variant="outline" className="h-20 w-full flex flex-col gap-2 hover:shadow-md transition-all">
                    <MapPin className="w-6 h-6" />
                    <span className="text-sm">Plan Routes</span>
                  </Button>
                </Link>
                <Link to={createPageUrl("Finance")}>
                  <Button variant="outline" className="h-20 w-full flex flex-col gap-2 hover:shadow-md transition-all">
                    <DollarSign className="w-6 h-6" />
                    <span className="text-sm">Financial Report</span>
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
      <QuickTour 
        tour={tours['dashboard-overview']}
        isOpen={isTourActive}
        onClose={handleCloseTour}
      />
    </div>
  );
};

// Main Export - Wrapped with PeriodProvider
export default function Dashboard() {
  return (
    <PeriodProvider>
      <DashboardContent />
    </PeriodProvider>
  );
}
